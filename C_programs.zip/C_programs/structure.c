#include<stdio.h>
struct student
{
	int rollno;
	char name[14];
	float percentage;
};
int main()
{
       	struct student s;
	scanf("%d %s %f",&s.rollno,s.name,&s.percentage);
	printf("Rollnumber : %d\n",s.rollno);
	printf("Name :%s\n",s.name);
	printf("percentage: %f\n",s.percentage);
}
