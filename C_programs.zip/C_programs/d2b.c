#include<stdio.h>
int main()
{
	int n,mask,res;
	printf("Enter a num: ");
	scanf("%d",&n);
	int i=31;
	while(i>=0)
	{
		mask=1<<i;
		res=n&mask;
		if(res==0)
		{
			printf("0");
		}
		else
		{
			printf("1");
		}
		i--;
	}

}
