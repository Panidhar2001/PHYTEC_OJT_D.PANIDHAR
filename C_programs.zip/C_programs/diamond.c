#include <stdio.h>

int main()
{
  int n, c, k;

  printf("Enter number of rows\n");
  scanf("%d", &n);

  for (k = 1; k <= n/2; k++)
  {
    for (c = 1; c <= n - k; c++)
      printf(" ");

    for (c = 1; c <= 2 * k - 1; c++)
      printf("*");

    printf("\n");
  }

  for (k = 1; k <= n/2; k++)
  {
    for (c = 1; c <= k; c++)
      printf(" ");

    for (c = 1; c <= 2 * (n - k)-1 ; c++)
      printf("*");

    printf("\n");
  }

  return 0;
}

