#include <stdio.h>

int main() {
    int a[5], b[5];
    int c[5] = {1, 2, 3, 4, 5};
    int evenIndex = 0, oddIndex = 0;

    for (int i = 0; i < 5; i++) {
        if (c[i] % 2 == 0) {
            a[evenIndex] = c[i];
            evenIndex++;
        } else {
            b[oddIndex] = c[i];
            oddIndex++;
        }
    }

    printf("Even numbers are: ");
    for (int i = 0; i < evenIndex; i++) {
        printf("%d ", a[i]);
    }
    printf("\n");

    printf("Odd numbers are: ");
    for (int i = 0; i < oddIndex; i++) {
        printf("%d ", b[i]);
    }
    printf("\n");

    return 0;
}
