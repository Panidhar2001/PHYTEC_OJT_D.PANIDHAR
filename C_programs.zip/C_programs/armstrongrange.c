#include<stdio.h>
#include<math.h>
int main()
{
	int temp=0,a,b;
	printf("enter a,b values: ");
	scanf("%d%d",&a,&b);
	if(a>b)
	{
		temp=a;
		a=b;
		b=temp;
	}
	for(int i=a;i<=b;i++)
	{
		int temp1=i;
		int temp2=i;
		int count=0;
		while(temp1)
		{
			 temp1=temp1/10;
			 count ++;
		}
		int sum=0;
		while(temp2)
		{
			int rem=temp2%10;
			sum=sum+pow(rem,count);
			temp2=temp2/10;
		}
		if(sum==i)
		{
			printf("%d\t",i);
		}
	}
}
