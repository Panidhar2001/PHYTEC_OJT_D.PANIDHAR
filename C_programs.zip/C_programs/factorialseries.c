#include<stdio.h>

int factof(int i)
{
	if(i==0||i==1)
		return 1;
	else
		return i * factof(i-1);
}
int main()
{
	int sum=0,n;
	printf("enter value: ");
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		sum=sum+factof(i);
		printf("%d!",i);
		if(i<n)
		{
			printf("+");
		}
	}
	printf("=%d",sum);
}




