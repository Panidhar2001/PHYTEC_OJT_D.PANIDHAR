#include<stdio.h>
int main()
{
	int rem,n,binary=0,weight=1;
	printf("enter a number: ");
	scanf("%d",&n);
	while(n!=0)
	{
		rem=n%2;
		binary=binary+rem*weight;
		n=n/2;
		weight=weight*10;
	}
	printf("%d",binary);
}
