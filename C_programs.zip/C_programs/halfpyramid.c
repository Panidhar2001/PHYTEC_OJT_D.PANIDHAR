#include<stdio.h>
int main()
{
	int i,j,num;
	printf("enter number: ");
	scanf("%d",&num);
	for(i=1;i<=num;i++)
	{
		for(j=1;j<=i*2-1;j++)
		{
			printf("%d",j);
		}
		printf("\n");
	}
}

