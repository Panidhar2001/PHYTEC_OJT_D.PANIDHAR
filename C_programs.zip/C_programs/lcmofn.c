#include <stdio.h>

int findLCMArray(int arr[], int n) {
    int max = arr[0];

    // Find the maximum element in the array
    for (int i = 1; i < n; i++) {
        if (arr[i] > max) {
            max = arr[i];
        }
    }

    // Find the LCM for the maximum element and the other elements in the array
    while (1) {
        int isLCM = 1;
        for (int i = 0; i < n; i++) {
            if (max % arr[i] != 0) {
                isLCM = 0;
                break;
            }
        }

        if (isLCM) {
            return max;
        }

        max++;
    }
}

int main() {
    int n;

    // Input the number of elements in the array
    printf("Enter the number of elements: ");
    scanf("%d", &n);

    int arr[n];

    // Input array elements
    printf("Enter the array elements:\n");
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    // Find and print the LCM of the array elements
    int lcm = findLCMArray(arr, n);
    printf("LCM of the array elements is: %d\n", lcm);

    return 0;
}

