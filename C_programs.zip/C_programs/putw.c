#include <stdio.h>

int main() {
    FILE *file = fopen("t.txt", "r");
    if (file == NULL) {
        perror("Error opening file");
        return 1;
    }

    int num = getw(file);
    printf("Read value: %d\n", num);

    fclose(file);
    return 0;
}

