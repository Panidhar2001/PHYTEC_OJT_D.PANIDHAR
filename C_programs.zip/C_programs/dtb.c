#include<stdio.h>
int main()
{

	int a[14],i,n;
	printf("enter a number: ");
	scanf("%d",&n);
	for(i=0;n>0;i++)
	{
		a[i]=n%2;
		n=n/2;
		printf("%d",a[i]);
	}
}
