#include<stdio.h>
int dtb(int n);
int main()
{
	int n;
	printf("enter a number: ");
	scanf("%d",&n);
	printf("%d",dtb(n));
}
int dtb(int n)
{
	dtb(n/2);
	printf("%d",n/2);
	return n/2;
}
