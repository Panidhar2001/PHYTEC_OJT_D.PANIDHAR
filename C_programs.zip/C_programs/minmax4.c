#include <stdio.h>

int main() {
    int a,b,c,d;
    printf("enter values: ");
    scanf("%d%d%d%d",&a,&b,&c,&d);
    if((a>b&a>c)&&a>d)
    {
        printf("a is greater: %d",a);
    }
    else if(b>c&b>d)
    {
        printf("b is greater : %d",b);
    }
    else if(c>d)
    {
        printf("c is greater: %d",c);
    }
    else
    {
        printf("d is greater :%d",d);
    }
    if((a<b&a<c)&&a<d)
    {
        printf("a is lesser: %d",a);
    }
    else if(b<c&b<d)
    {
        printf("b is lesser : %d",b);
    }
    else if(c<d)
    {
        printf("c is lesser: %d",c);
    }
    else
    {
        printf("d is lesser :%d",d);
    }
}
