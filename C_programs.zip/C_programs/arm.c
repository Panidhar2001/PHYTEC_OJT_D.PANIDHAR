#include <stdio.h>
#include <math.h>

int main()
{
	int num,x,sum=0,count=0,temp,i,rem;
	printf("enter a number: ");
	scanf("%d",&num);
	temp=num;
	while(num>=0)
	{
		num=num/10;
		count ++;
	}
	for(i=1;i<=count;i++)
	{
		rem=temp%10;
		sum=sum+pow(rem,count);
		temp=temp/10;
	}
	printf("%d",sum);
	if(sum==temp)
		printf("a");
	else
		printf("n");
}



