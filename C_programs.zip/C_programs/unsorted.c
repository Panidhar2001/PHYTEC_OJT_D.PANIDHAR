#include<stdio.h>
int main()
{
	int i,j,count=1;
	int n=6;
	int arr[]={2,1,5,2,9,6,1};
	for(i=0;i<n;i++)
	{
		for(j=i+1;j<n;j++)
		{
			if(arr[i]==arr[j])
			{
				count++;
			}
		}
			printf("element is %d and count is %d\n	",arr[i],count); 
	}
}

