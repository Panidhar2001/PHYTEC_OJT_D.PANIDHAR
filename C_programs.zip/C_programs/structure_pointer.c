#include <stdio.h>
struct person
{
   int age;
   char name[10];
   float percentage;
};

int main()
{
    struct person *Ptr, person;
    Ptr = &person;   
    
    printf("Enter age: ");
    scanf("%d", &Ptr->age);

    printf("Enter name: ");
    scanf("%s", Ptr->name);

    printf("enter percentage: ");
    scanf("%f", &Ptr->percentage);
    
    printf("Age: %d\n", Ptr->age);
    printf("name: %s\n",Ptr->name);
    printf("percentage: %f\n", Ptr->percentage);

    return 0;
}
