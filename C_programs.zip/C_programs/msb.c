#include<stdio.h>
int main() {
	int i,x;
	printf("Enter a number:\n");
	scanf("%d",&x);
	for(i=15;i>=0;i--) {
		if(i==15) {
			if(x & 0x1<<i) {
			printf("1");
			}
			else
				printf("0");
		}
	}
}
