#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define SERVER_IP "192.168.0.193"
#define PORT 8080
#define MAX_MESSAGE_SIZE 1024

void error(const char *msg) {
    perror(msg);
    exit(1);
}

int main() {
    int sockfd, n;
    struct sockaddr_in serv_addr;
    socklen_t servlen = sizeof(serv_addr);
    char buffer[MAX_MESSAGE_SIZE];
    char message[MAX_MESSAGE_SIZE];

    // Create socket
    if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
        error("ERROR opening socket");

    // Initialize server address
    memset(&serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);
    if (inet_aton(SERVER_IP, &serv_addr.sin_addr) == 0) {
        fprintf(stderr, "Invalid address\n");
        exit(1);
    }

    while (1) {
        printf("Enter message: ");
        fgets(message, MAX_MESSAGE_SIZE, stdin);

        // Send message to server
        if (sendto(sockfd, message, strlen(message), 0, (struct sockaddr *) &serv_addr, servlen) < 0)
            error("ERROR in sendto");

        // Clear the buffer
        memset(buffer, 0, MAX_MESSAGE_SIZE);

        // Receive response from server
        n = recvfrom(sockfd, buffer, MAX_MESSAGE_SIZE, 0, (struct sockaddr *) &serv_addr, &servlen);
        if (n < 0)
            error("ERROR in recvfrom");

        // Print response
        printf("Server response: %s\n", buffer);
    }

    close(sockfd);
    return 0;
}
