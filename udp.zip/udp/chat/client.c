#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define SERVER_IP "192.168.0.188"
#define PORT 1234
#define BUFFER_SIZE 1024

int main() {
    int sockfd;
    struct sockaddr_in serverAddr;
    char buffer[BUFFER_SIZE];

    // Create socket
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        perror("Error in socket creation");
        exit(EXIT_FAILURE);
    }

    // Setup server address
    memset(&serverAddr, 0, sizeof(serverAddr));
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = inet_addr(SERVER_IP);
    serverAddr.sin_port = htons(PORT);

    while (1) {
        // Get a message from the user
        printf("Enter a message: ");
        fgets(buffer, BUFFER_SIZE, stdin);

        // Send the message to the server
        ssize_t bytesSent = sendto(sockfd, buffer, strlen(buffer), 0, (struct sockaddr *)&serverAddr, sizeof(serverAddr));
        if (bytesSent < 0) {
            perror("Error in sendto");
            exit(EXIT_FAILURE);
        }

        // Receive response from server
        ssize_t bytesRead = recvfrom(sockfd, buffer, BUFFER_SIZE, 0, NULL, NULL);
        if (bytesRead < 0) {
            perror("Error in recvfrom");
            exit(EXIT_FAILURE);
        }

        // Print server's response
        buffer[bytesRead] = '\0';
        printf("Server response: %s\n", buffer);
    }

    // Close socket
    close(sockfd);

    return 0;
}

