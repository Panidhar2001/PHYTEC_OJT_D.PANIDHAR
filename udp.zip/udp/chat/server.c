#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 1234
#define BUFFER_SIZE 1024

int main() {
    int sockfd;
    struct sockaddr_in serverAddr, clientAddr;
    socklen_t addrLen = sizeof(clientAddr);
    char buffer[BUFFER_SIZE];

    // Create socket
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        perror("Error in socket creation");
        exit(EXIT_FAILURE);
    }

    // Setup server address
    memset(&serverAddr, 0, sizeof(serverAddr));
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = INADDR_ANY;
    serverAddr.sin_port = htons(PORT);

    // Bind socket
    if (bind(sockfd, (struct sockaddr *)&serverAddr, sizeof(serverAddr)) < 0) {
        perror("Error in binding");
        exit(EXIT_FAILURE);
    }

    printf("Server listening on port %d...\n", PORT);

    while (1) {
        // Receive message from client
        ssize_t bytesRead = recvfrom(sockfd, buffer, BUFFER_SIZE, 0, (struct sockaddr *)&clientAddr, &addrLen);
        if (bytesRead < 0) {
            perror("Error in recvfrom");
            exit(EXIT_FAILURE);
        }

        // Print received message
        buffer[bytesRead] = '\0';
        printf("Received message from client: %s\n", buffer);

        // Get a message from the user
        printf("Enter a response: ");
        fgets(buffer, BUFFER_SIZE, stdin);

        // Send the response back to the client
        ssize_t bytesSent = sendto(sockfd, buffer, strlen(buffer), 0, (struct sockaddr *)&clientAddr, addrLen);
        if (bytesSent < 0) {
            perror("Error in sendto");
            exit(EXIT_FAILURE);
        }
    }

    // Close socket
    close(sockfd);

    return 0;
}

