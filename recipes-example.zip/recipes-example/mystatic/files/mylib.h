#ifndef __LIB_H
#define __LIB_H


int add(int quant1, int quant2);
int sub(int quant1, int quant2);
int mul(int quant1, int quant2);
int div(int quant1, int quant2);
void print(char *string, int times);

#endif
