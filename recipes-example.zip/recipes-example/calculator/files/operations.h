#ifndef OPERATIONS_H
#define OPERATIONS_H

int add(int a, int b);
int subtract(int a, int b);
int multiply(int a, int b);
int divide(int a, int b);

#endif

