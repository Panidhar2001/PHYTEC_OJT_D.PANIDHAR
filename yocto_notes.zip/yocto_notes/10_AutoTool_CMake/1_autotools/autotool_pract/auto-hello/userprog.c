#include <stdio.h>

int main()
{
	printf("Learning Autotools\n");
	return 0;

}
