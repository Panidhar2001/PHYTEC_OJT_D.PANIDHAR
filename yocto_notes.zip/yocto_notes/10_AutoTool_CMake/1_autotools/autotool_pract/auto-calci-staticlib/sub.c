#include "myheader.h"

double subtract(double a, double b) {
    return a - b;
}

