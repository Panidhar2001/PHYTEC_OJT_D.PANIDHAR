#include <stdio.h>
#include "mylib.h"

int main()
{
	print("Hello World\n", 5);
	return 0;
}
